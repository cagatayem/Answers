// 1. Please write a function that reverses a string
const reverse = (str) =>{
  let newStr = ""
  for (let i = str.length-1 ; 0 <= i ; i--){

    newStr += str[i];
  }
  return newStr;
};
console.log(reverse("Hello World"))

// 2. Please write a function that filters out numbers from a list

const filterNumbers = (list) => {
  return list.filter(number => isNaN(number) )
};

console.log(filterNumbers([2,3,"a","b",5,3,23,24]))

// 3. Please write a function that shows the usage of closures
const add = function (number1) {
  return function (number2) {
    return number1 + number2;
  };
};
const func1 = add(5);
console.log(func1(4));

// 4. Please write a recursive function that flattens an list of items
// example input [[2, [4, [44,5,6]]], [4,5,6], [[2,4], 4], 5]]
// example output [2, 4, 44, 5, 6, 4, 5, 6, 2, 4, 4, 5]
function flatten(array) {
  let flatArray = [];
  for (let i = 0; i < array.length; i++) {
      if (Array.isArray(array[i])) {
          flatArray.push(...flatten(array[i]));
      } else {
          flatArray.push(array[i]);
      }
  }
  return flatArray;
}

console.log(flatten([[2, [4, [44,5,6]]], [4,5,6], [[2,4], 4], 5]))

// 5. Please write a function that finds all common elements of two arrays(only primitive types as array elements, order doesn't matter)
// example inputs ['b', 3, 4, 76, 'c'], ['a', 'b', 4, 76, 21, 'e']
// example output ['b', 4, 76]
function commonElement(arr1, arr2){
  const filteredArray = arr1.filter(value => arr2.includes(value));
  return filteredArray
}
console.log(commonElement( ['a', 'b', 4, 76, 21, 'e'],['b', 3, 4, 76, 'c']))

// 6. Please write a function that finds all different elements of two arrays(only primitive types as array elements, order doesn't matter)
// example inputs ['b', 3, 4, 76, 'c'], ['a', 'b', 4, 76, 21, 'e']
// example output ['a', 3, 21, 'c', 'e']
function commonElement(arr1, arr2){

  const filteredArray1 = arr2.filter(value => !arr1.includes(value));
  const filteredArray2 = arr1.filter(value => !arr2.includes(value));
  const newArr= [...filteredArray1, ...filteredArray2]
  return newArr
}
console.log(commonElement( ['b', 3, 4, 76, 'c'], ['a', 'b', 4, 76, 21, 'e']))

// 7. Please write a function that transforms an object to a list of [key, value] tuples.
// example input { color: 'Blue', id: '22', size: 'xl' }
// example output [['color', 'blue'], ['id', '22'], ['size', 'xl']]
function transform1 (obj){
  return Object.entries(obj)
}

console.log(transform1({ color: 'Blue', id: '22', size: 'xl' }))

// 8. Please write a function that transforms a list of [key, value] tuples to object. // reverse or task 7
// example input [['color', 'blue'], ['id', '22'], ['size', 'xl']]
// example output { color: 'Blue', id: '22', size: 'xl' }
function transform2 (array){
  return Object.fromEntries(array)
}

console.log(transform2( [['color', 'blue'], ['id', '22'], ['size', 'xl']]))

// 9. Please write a function that takes two arrays of items and returns an array of tuples made from two input arrays at the same indexes. Excessive items should be dropped.
// example input [1,2,3], [4,5,6,7]
// example output [[1,4], [2,5], [3,6]]
function arrCombine(arr1,arr2) {
  const newArr = []
  for(let i=0; i<arr1.length; i++){
    for(let k=i; k<arr2.length; k++){
      newArr.push([arr1[i],arr2[k]])
      break;
    }
  }
  return newArr
}


console.log(arrCombine([1,2,3], [4,5,6,7]));

// 10. Please write a function which takes a path(path is an array of keys) and object, then returns value at this path. If value at path doesn't exists, return undefined.
// example inputs ['a', 'b', 'c', 'd'], { a: { b: { c: { d: '23' } } } }
// example output '23'
function get(obj, path){
  let current = obj;
  for(let i=0 ; i<path.length; i++){
    if(!current[path[i]]) return undefined
    current = current[path[i]]
  }

  return current
}

console.log(get({ a: { b: { c: { d: '33' } } } },['a', 'b', 'c', 'd'],))


// 11. Please write compare function which compares 2 objects for equality.
// example input { a: 'b', c: 'd' }, { c: 'd', a: 'b' }  /// output true
// example input { a: 'c', c: 'a' }, { c: 'd', a: 'b', q: 's' }  /// output false

function equality(obj1, obj2){
  const result = Object.keys(obj1).every((key) =>  obj1[key] === obj2[key])
  return result
}

console.log(equality({ a: 'c', c: 'a' }, { c: 'd', a: 'b', q: 's' }))

// 12. Please write a function which takes a list of keys and an object, then returns this object, just without keys from the list
// example input ['color', 'size'], { color: 'Blue', id: '22', size: 'xl' }
// example output { id: '22' }

function withoutKey (keys, object){
 const newArr= []
 const convert = Object.keys(object).filter((key) => {
  if(keys.indexOf(key) === -1){
    newArr.push( key)
    newArr.push(object[key])
  }
 })
 return Object.fromEntries([newArr])
}

console.log(withoutKey(['color', 'size'],{ color: 'Blue', id: '22', size: 'xl' }))

