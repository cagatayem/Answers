import React, {useState,useEffect} from 'react';
import axios from "axios"
import "./App.css"

const url = "https://jsonplaceholder.typicode.com/users"

const App = () => {

  const [users, setUsers] = useState([]);
  const [userMatch, setUserMatch] = useState([])
  const [input, setInput] = useState("")

  const fetchUsers = async () =>{
    const response = await axios.get(url);
    setUsers(response.data);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const inputHandler = (e) => {
    let value = e.target.value;
    const result = users.filter(user => 
    user.name.toLowerCase().includes(value.toLowerCase())
    );

    setInput(value)
    setUserMatch(result)
  }

  const matchHandler = (username) =>{
    setInput(username)
    setUserMatch([])
  }
  return (
    <div className="app">
      <h1 className="app_header">Search User</h1>
      <input 
      className="app__input "
      type="text"
      value={input}
      placeHolder="Enter a name"
      onChange={inputHandler}
      onBlur = {() => {
        setTimeout(() => {
          setUserMatch([])
        },100)
      }}
      />
      {input.length > 0 ? userMatch.map(user =>
        <div className="app__result" key={user.key} onClick={() => matchHandler(user.name)}> {user.name} </div>): []}
    </div> 
  );
}

export default App;
